# Update MUFU (More User Friendly Update)

This is the first version of our QGIS installation script!

# Features:
1. Install QGIS
2. Create a crontab for automatic copy to home dir (takes one minute before files are being copied)
3. Install the automatic removal script (for schools that use one account for everyone and don't want others to see their files, files are removed on login and NOT on the logout)

# This version was designed for chromebooks only and may or may not work on other linux based devices...