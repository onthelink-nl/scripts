# INSTRUCTIONS ARE INSIDE THE PDF FILE
[QGIS Instructions](https://github.com/onthelink-nl/scripts/blob/master/MUFU/qgis/MUFU/Tutorials/INSTRUCTIONS/QGIS%20Instructions%20(For%20downloaded%20releases).pdf "Instructions")
