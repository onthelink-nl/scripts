###################################
           INSTALLATION
         PROBABLY OUTDATED
               -----
   STUFF MIGHT NOT WORK PROPERLY   	
       YOU HAVE BEEN WARNED
###################################
===================================
###################################
VERSION: MUFU
UPDATE: 2.8.7
STATE: STABLE

DATE: 04 October 2019
###################################
===================================

INSTRUCTIONS:

https://github.com/onthelink-nl/scripts/blob/master/MUFU/qgis/MUFU/Tutorials/INSTRUCTIONS/QGIS%20Instructions%20(For%20downloaded%20releases).pdf
